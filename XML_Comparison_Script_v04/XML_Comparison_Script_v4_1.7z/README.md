

Details about the data set
data_set1:  Test cases match in both files
data_set2:  One less test case in File 2/testng-results_new file [i.e, TSQA_10738]
data_set3:  One less test case in File 2/testng-results_new file [i.e, TSQA_10409] and two less test cases in File 1/testng-results_old file [TSQA_6439, TSQA_12058]


Import the missing dependencies with 'pip install' command